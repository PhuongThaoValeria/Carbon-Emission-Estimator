
// This declares the pdfjsLib object that is loaded globally from the CDN in index.html
// This allows TypeScript to recognize it without needing to import it as a module.
declare var pdfjsLib: any;
