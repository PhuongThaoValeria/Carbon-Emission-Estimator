export type AppState = 'idle' | 'processing' | 'extracted' | 'result' | 'error';

export type CarbonActivityType = 'shipping' | 'unknown';

export interface CarbonActivity {
  activityType: CarbonActivityType;
  parameters: {
    origin?: string; // Country or City
    destination?: string; // Country or City
    weight?: number;
    weight_unit?: 'kg' | 'lb';
    hs_code?: string;
    product?: string;
  };
}

export interface CalculationBreakdown {
    formula: string;
    steps: string[];
    source?: string;
}

export interface Suggestion {
  title: string;
  description: string;
  isMostEconomical: boolean;
}

export interface EmissionComponent {
    value: number;
    breakdown: CalculationBreakdown;
}

export interface ThresholdComparison {
    destinationCountry: string;
    threshold: number;
    thresholdSource: string; // e.g., "OECD Environmental Data (2024)"
    comparisonResult: 'Above' | 'Below' | 'Equal';
    differencePercentage: number;
    interpretation: string;
    verificationSource: string; // URL
}

export interface CarbonResult {
  totalFootprint: number;
  co2e_unit: string;
  confidenceRange: [number, number];
  productEmissions: EmissionComponent;
  transportEmissions: EmissionComponent;
  activity: CarbonActivity;
  thresholdComparison?: ThresholdComparison;
  suggestions?: Suggestion[];
}
