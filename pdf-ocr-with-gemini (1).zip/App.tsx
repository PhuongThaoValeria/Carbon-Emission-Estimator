import React, { useState, useCallback } from 'react';
import FileUpload from './components/FileUpload';
import ProcessingView from './components/ProcessingView';
import ResultView from './components/ResultView';
import AnalysisView from './components/AnalysisView';
import { convertPdfToImages } from './utils/pdfUtils';
import { extractCarbonActivity, getEmissionReductionSuggestions } from './services/geminiService';
import { calculateCarbonEmission } from './services/climatiqService';
import { AppState, CarbonResult, CarbonActivity } from './types';
import { CalculatorIcon } from './components/icons/CalculatorIcon';
import { ExclamationTriangleIcon } from './components/icons/ExclamationTriangleIcon';

function App() {
  const [appState, setAppState] = useState<AppState>('idle');
  const [processingState, setProcessingState] = useState({ currentPage: 0, totalPages: 0, message: '' });
  const [result, setResult] = useState<CarbonResult | null>(null);
  const [extractedActivity, setExtractedActivity] = useState<CarbonActivity | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [currentFile, setCurrentFile] = useState<File | null>(null);

  const handleUpdateActivity = (updatedActivity: CarbonActivity) => {
    setExtractedActivity(updatedActivity);
  };


  const handleFileSelect = useCallback(async (file: File) => {
    setCurrentFile(file);
    setAppState('processing');
    setError(null);
    setResult(null);
    setExtractedActivity(null);
    setProcessingState({ currentPage: 0, totalPages: 0, message: 'Preparing document...' });

    try {
      // Step 1: Convert PDF to images
      setProcessingState(prev => ({ ...prev, message: 'Reading pages from PDF...' }));
      const images = await convertPdfToImages(file, ({ currentPage, totalPages }) => {
        setProcessingState(prev => ({ ...prev, currentPage, totalPages }));
      });

      // Step 2: Extract structured data with Gemini
      setProcessingState(prev => ({ ...prev, message: 'Analyzing document with Gemini...' }));
      const activity = await extractCarbonActivity(images);
      
      setExtractedActivity(activity);
      setAppState('extracted');

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      console.error(err);
      setError(errorMessage);
      setAppState('error');
    }
  }, []);

  const handleCalculate = useCallback(async () => {
    if (!extractedActivity) return;

    setAppState('processing');
    setProcessingState({ currentPage: 0, totalPages: 0, message: 'Calculating emissions & performing compliance analysis...' });
    
    try {
        const emissionResult = await calculateCarbonEmission(extractedActivity);

        if (emissionResult.thresholdComparison?.comparisonResult === 'Above') {
            setProcessingState(prev => ({ ...prev, message: 'Analyzing emission reduction strategies...' }));
            const suggestions = await getEmissionReductionSuggestions(emissionResult);
            emissionResult.suggestions = suggestions;
        }

        setResult(emissionResult);
        setAppState('result');
    } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
        console.error(err);
        setError(errorMessage);
        setAppState('error');
    }
  }, [extractedActivity]);

  const handleReset = () => {
    setAppState('idle');
    setResult(null);
    setError(null);
    setCurrentFile(null);
    setExtractedActivity(null);
    setProcessingState({ currentPage: 0, totalPages: 0, message: '' });
  };

  const renderContent = () => {
    switch (appState) {
      case 'idle':
        return <FileUpload onFileSelect={handleFileSelect} />;
      case 'processing':
        return <ProcessingView {...processingState} />;
      case 'extracted':
        return extractedActivity && <AnalysisView activity={extractedActivity} onCalculate={handleCalculate} fileName={currentFile?.name || 'document'} onReset={handleReset} onUpdateActivity={handleUpdateActivity} />;
      case 'result':
        return result && <ResultView result={result} fileName={currentFile?.name || 'document'} onReset={handleReset} />;
      case 'error':
        return (
          <div className="text-center">
            <ExclamationTriangleIcon className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-red-400 mb-2">An Error Occurred</h2>
            <p className="text-slate-400 mb-6 max-w-md mx-auto">{error}</p>
            <button
              onClick={handleReset}
              className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-slate-900 min-h-screen text-slate-200 flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8">
      <header className="w-full max-w-4xl mx-auto mb-8 text-center">
        <div className="flex items-center justify-center gap-3 mb-2">
            <CalculatorIcon className="w-10 h-10 text-indigo-400" />
            <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-green-300 to-indigo-400 text-transparent bg-clip-text">
              PDF Carbon Estimator
            </h1>
        </div>
        <p className="text-slate-400 max-w-2xl mx-auto">
          Upload a shipping document (e.g., bill of lading, commercial invoice) to extract key data and estimate the carbon footprint of your freight.
        </p>
      </header>
      <main className="w-full max-w-4xl mx-auto flex-grow flex items-center justify-center">
        {renderContent()}
      </main>
      <footer className="w-full max-w-4xl mx-auto mt-8 text-center text-slate-500 text-sm">
        <p>Powered by Google Gemini.</p>
      </footer>
    </div>
  );
}

export default App;
