import { CarbonActivity, CarbonResult, CalculationBreakdown } from '../types';
import { getDistance, getProductEmissionFactor, getCarbonThresholdDetails } from './geminiService';

// --- Internal Carbon Calculation Engine for Shipping ---

// Source: GLEC Framework, values are illustrative. User prompt specified 0.010 for sea freight.
const EMISSION_FACTORS = {
    SEA_FREIGHT: 0.010, // kg CO2e per tonne-km
};

/**
 * Calculates carbon emissions using an AI-powered distance estimation.
 */
export async function calculateCarbonEmission(activity: CarbonActivity): Promise<CarbonResult> {
  if (activity.activityType === 'unknown' || activity.activityType !== 'shipping') {
    throw new Error('Could not identify a shipping activity in the document.');
  }

  const { origin, destination, weight, weight_unit = 'kg', hs_code } = activity.parameters;

  if (!origin || !destination || typeof weight !== 'number' || !hs_code) {
    throw new Error('Missing origin, destination, weight, or HS code for full carbon footprint calculation.');
  }

  // --- Step 1: Product Embedded Emissions ---
  const { factor: productEmissionFactor, source: productEmissionSource } = await getProductEmissionFactor(hs_code, origin);
  const weightInKg = weight_unit === 'lb' ? weight * 0.453592 : weight;
  const productEmissionsValue = productEmissionFactor * weightInKg;
  const productEmissionsBreakdown: CalculationBreakdown = {
      formula: 'Product Weight (kg) × Emission Factor',
      steps: [
          `Product Weight: ${weightInKg.toFixed(2)} kg`,
          `Emission Factor: ${productEmissionFactor.toFixed(4)} kg CO₂e/kg`,
          `Calculation: ${weightInKg.toFixed(2)} kg × ${productEmissionFactor.toFixed(4)} = ${productEmissionsValue.toFixed(3)} kg CO₂e`,
      ],
      source: productEmissionSource,
  };
  
  // --- Step 2: Transport Emissions ---
  const weightInTonnes = weightInKg / 1000;
  const distance = await getDistance(origin, destination);
  const transportEmissionsValue = weightInTonnes * distance * EMISSION_FACTORS.SEA_FREIGHT;
  const transportEmissionsBreakdown: CalculationBreakdown = {
      formula: '(Weight in tonnes × Estimated Distance) × Emission Factor',
      steps: [
        `Weight: ${weightInKg.toFixed(2)} kg (${weightInTonnes.toFixed(4)} tonnes)`,
        `Estimated Distance: ${distance} km (Estimated by Gemini)`,
        `Emission Factor: ${EMISSION_FACTORS.SEA_FREIGHT} kg CO₂e/tkm (Sea Freight)`,
        `Calculation: (${weightInTonnes.toFixed(4)} t × ${distance} km) × ${EMISSION_FACTORS.SEA_FREIGHT} = ${transportEmissionsValue.toFixed(3)} kg CO₂e`,
      ],
      source: 'GLEC Framework (Illustrative)',
  };

  // --- Step 3: Total Footprint & Confidence ---
  const totalFootprint = productEmissionsValue + transportEmissionsValue;
  const confidenceRange: [number, number] = [totalFootprint * 0.85, totalFootprint * 1.15];
  
  // --- Step 4: Threshold Comparison (AI-Powered) ---
  const thresholdComparison = await getCarbonThresholdDetails(destination, totalFootprint);

  return {
    totalFootprint,
    co2e_unit: 'kg',
    confidenceRange,
    productEmissions: {
        value: productEmissionsValue,
        breakdown: productEmissionsBreakdown,
    },
    transportEmissions: {
        value: transportEmissionsValue,
        breakdown: transportEmissionsBreakdown,
    },
    activity,
    thresholdComparison,
  };
}
