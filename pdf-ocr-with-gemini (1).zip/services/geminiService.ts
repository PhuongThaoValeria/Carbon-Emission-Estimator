import { GoogleGenAI, Type } from "@google/genai";
import { CarbonActivity, CarbonResult, Suggestion, ThresholdComparison } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const model = 'gemini-2.5-flash';

const extractionPrompt = `You are an AI assistant specialized in extracting structured data from shipping and logistics documents for carbon accounting. Analyze the content of the provided document pages and identify key information about the freight.
- Extract the 'origin' and 'destination' countries or cities.
- Extract the total 'weight' of the shipment and its 'weight_unit' ('kg' or 'lb').
- Extract the 'hs_code' (Harmonized System code).
- Extract a brief 'product' description.
Return the result as a single JSON object with an activityType of 'shipping'. If the document is not a shipping document, return 'unknown'.`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        activityType: {
            type: Type.STRING,
            description: "The type of activity. Should be 'shipping' for logistics documents or 'unknown'.",
            enum: ['shipping', 'unknown']
        },
        parameters: {
            type: Type.OBJECT,
            description: "Parameters for the shipping activity.",
            properties: {
                origin: { type: Type.STRING, description: "Origin country or city." },
                destination: { type: Type.STRING, description: "Destination country or city." },
                weight: { type: Type.NUMBER, description: "Total weight of the shipment." },
                weight_unit: {
                    type: Type.STRING,
                    description: "Unit of weight.",
                    enum: ['kg', 'lb']
                },
                hs_code: { type: Type.STRING, description: "Harmonized System (HS) code for the product." },
                product: { type: Type.STRING, description: "Brief description of the product being shipped." }
            }
        }
    },
    required: ["activityType", "parameters"]
};


export async function extractCarbonActivity(images: string[]): Promise<CarbonActivity> {
    if (!process.env.API_KEY) {
        throw new Error("Gemini API key is not configured. Please set the API_KEY environment variable.");
    }
    
    const textPart = { text: extractionPrompt };
    const imageParts = images.map((img) => ({
        inlineData: {
            mimeType: 'image/jpeg',
            data: img,
        },
    }));

    const contents = {
        parts: [
            textPart,
            ...imageParts
        ]
    };

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: contents,
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
                temperature: 0.1,
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString) as CarbonActivity;

        if (result.activityType && result.parameters) {
            return result;
        } else {
            throw new Error("Invalid JSON structure received from API.");
        }

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        if (error instanceof Error && error.message.includes('API key not valid')) {
             throw new Error("The Gemini API key is invalid. Please check your API_KEY environment variable.");
        }
        throw new Error("Failed to extract data from Gemini API. The model may have returned an unexpected response.");
    }
}

export async function getDistance(origin: string, destination: string): Promise<number> {
    const distancePrompt = `As a logistics expert AI, what is the typical sea freight shipping distance in kilometers between "${origin}" and "${destination}"? Respond with only a JSON object containing a single key "distance" with the numerical value.`;
    
    const distanceSchema = {
        type: Type.OBJECT,
        properties: {
            distance: { 
                type: Type.NUMBER, 
                description: "The estimated sea freight shipping distance in kilometers."
            },
        },
        required: ["distance"]
    };

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: distancePrompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: distanceSchema,
                temperature: 0,
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);

        if (result && typeof result.distance === 'number') {
            return result.distance;
        } else {
            throw new Error("Invalid distance value received from Gemini.");
        }
    } catch (error) {
        console.error("Error getting distance from Gemini API:", error);
        if (error instanceof Error && error.message.includes('API key not valid')) {
             throw new Error("The Gemini API key is invalid. Please check your API_KEY environment variable.");
        }
        throw new Error("Failed to estimate shipping distance with AI. The model may have returned an unexpected response.");
    }
}

export async function getProductEmissionFactor(hsCode: string, origin: string): Promise<{ factor: number; source: string }> {
    const prompt = `As a sustainability analyst AI, what is a typical embedded emission factor (in kg CO₂e per kg of product) for a product with HS code "${hsCode}" originating from "${origin}"? Use a credible public LCA/MRIO database proxy (like EXIOBASE or Ecoinvent). Respond with only a JSON object containing "factor" (numerical value) and "source" (the database name and any assumptions).`;

    const schema = {
        type: Type.OBJECT,
        properties: {
            factor: { 
                type: Type.NUMBER, 
                description: "The embedded emission factor in kg CO₂e per kg of product."
            },
            source: {
                type: Type.STRING,
                description: "The source database or proxy used for the factor (e.g., 'EXIOBASE proxy (country-adjusted)')."
            }
        },
        required: ["factor", "source"]
    };

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
                temperature: 0.2,
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);

        if (result && typeof result.factor === 'number' && typeof result.source === 'string') {
            return result;
        } else {
            console.warn("Gemini returned an invalid format for emission factor, using default.");
            return { factor: 1.5, source: 'Default proxy value (API response invalid)' };
        }
    } catch (error) {
        console.error("Error getting product emission factor from Gemini API:", error);
         if (error instanceof Error && error.message.includes('API key not valid')) {
             throw new Error("The Gemini API key is invalid. Please check your API_KEY environment variable.");
        }
        return { factor: 1.5, source: 'Default proxy value (API error)' };
    }
}

export async function getCarbonThresholdDetails(destinationCountry: string, totalFootprint: number): Promise<ThresholdComparison | undefined> {
    if (!destinationCountry) return undefined;

    const prompt = `As a sustainability analyst AI, provide a carbon threshold comparison for a shipment.
Destination Country: ${destinationCountry}
Total Shipment Footprint: ${totalFootprint.toFixed(2)} kg CO₂e

Follow these steps:
1. Find a credible national or industry-specific carbon emission threshold (in kg CO₂e) for imports in the destination country. Use sources like OECD, World Bank, EEA, or official government data.
2. Compare the shipment's footprint to this threshold.
3. Calculate the percentage difference.
4. Provide a brief, 2-3 sentence interpretation of the result's significance for compliance or sustainability goals.

Return ONLY a single JSON object with the following structure and data types:
- "destinationCountry": string (The name of the country)
- "threshold": number (The value of the threshold in kg CO₂e)
- "thresholdSource": string (e.g., "OECD Environmental Data 2024")
- "comparisonResult": string (Enum: "Above", "Below", "Equal")
- "differencePercentage": number (The percentage difference, positive if above, negative if below)
- "interpretation": string (The 2-3 sentence analysis)
- "verificationSource": string (The exact URL to the source data if available, otherwise the organization's main climate data page)
`;

    const schema = {
        type: Type.OBJECT,
        properties: {
            destinationCountry: { type: Type.STRING },
            threshold: { type: Type.NUMBER },
            thresholdSource: { type: Type.STRING },
            comparisonResult: { type: Type.STRING, enum: ['Above', 'Below', 'Equal'] },
            differencePercentage: { type: Type.NUMBER },
            interpretation: { type: Type.STRING },
            verificationSource: { type: Type.STRING },
        },
        required: ["destinationCountry", "threshold", "thresholdSource", "comparisonResult", "differencePercentage", "interpretation", "verificationSource"]
    };

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
                temperature: 0.1,
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);
        
        if (result && typeof result.threshold === 'number') {
            return result as ThresholdComparison;
        }
        console.warn("Gemini returned invalid format for threshold details.", result);
        return undefined;

    } catch (error) {
        console.error("Error getting carbon threshold details from Gemini API:", error);
         if (error instanceof Error && error.message.includes('API key not valid')) {
             throw new Error("The Gemini API key is invalid. Please check your API_KEY environment variable.");
        }
        return undefined;
    }
}


const suggestionSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            title: { 
                type: Type.STRING,
                description: 'A concise title for the suggestion.'
            },
            description: { 
                type: Type.STRING,
                description: 'A short paragraph explaining the suggestion.'
            },
            isMostEconomical: { 
                type: Type.BOOLEAN,
                description: 'A boolean flag that is true for only one suggestion, identifying it as the most cost-effective.'
            }
        },
        required: ["title", "description", "isMostEconomical"]
    }
};

export async function getEmissionReductionSuggestions(result: CarbonResult): Promise<Suggestion[]> {
    const { parameters } = result.activity;
    const threshold = result.thresholdComparison?.threshold;
    if (!threshold) return [];

    const suggestionsPrompt = `You are an expert in sustainable logistics. A freight shipment's carbon emission is over the destination country's limit.

Shipment Details:
- Product: ${parameters.product || 'Not specified'}
- Origin: ${parameters.origin}
- Destination: ${parameters.destination}
- Weight: ${parameters.weight} ${parameters.weight_unit || 'kg'}

Emission Analysis:
- Calculated CO₂e: ${result.totalFootprint.toFixed(2)} kg
- Destination Threshold: ${threshold} kg

Based on this, provide a set of 3 clear, actionable, and concise suggestions to reduce the carbon footprint for future, similar shipments. For each suggestion, provide a 'title' and a short 'description'.
Crucially, identify which of the suggestions is likely the most economical for a business to implement and set its 'isMostEconomical' flag to true. Only one item in the array should have this flag set to true.
Return the result as a JSON array of objects.`;
    
    try {
        const response = await ai.models.generateContent({
            model,
            contents: suggestionsPrompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: suggestionSchema,
            },
        });
        
        const jsonString = response.text.trim();
        const suggestions = JSON.parse(jsonString) as Suggestion[];
        return suggestions;

    } catch (error) {
        console.error("Error getting suggestions from Gemini API:", error);
        return [];
    }
}
