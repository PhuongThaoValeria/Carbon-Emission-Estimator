
/**
 * Converts a PDF file into an array of base64 encoded image strings.
 * @param file The PDF file to process.
 * @param onProgress A callback function to report progress.
 * @returns A promise that resolves to an array of base64 image data strings (without the data URL prefix).
 */
export async function convertPdfToImages(
  file: File,
  onProgress: (progress: { currentPage: number; totalPages: number }) => void
): Promise<string[]> {
  const images: string[] = [];
  const fileReader = new FileReader();

  return new Promise((resolve, reject) => {
    fileReader.onload = async (event) => {
      if (!event.target?.result) {
        return reject(new Error("Failed to read file."));
      }

      try {
        const typedarray = new Uint8Array(event.target.result as ArrayBuffer);
        const pdf = await pdfjsLib.getDocument(typedarray).promise;
        const totalPages = pdf.numPages;
        onProgress({ currentPage: 0, totalPages });

        for (let i = 1; i <= totalPages; i++) {
          const page = await pdf.getPage(i);
          const viewport = page.getViewport({ scale: 1.5 });
          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          
          if(!context) {
            return reject(new Error('Could not get canvas context'));
          }

          canvas.height = viewport.height;
          canvas.width = viewport.width;

          const renderContext = {
            canvasContext: context,
            viewport: viewport,
          };

          await page.render(renderContext).promise;
          
          // The data URL is e.g. "data:image/jpeg;base64,...."
          // We only want the part after the comma.
          const imageDataUrl = canvas.toDataURL('image/jpeg', 0.9);
          const base64Data = imageDataUrl.split(',')[1];
          images.push(base64Data);

          onProgress({ currentPage: i, totalPages });
        }
        resolve(images);
      } catch (error) {
        console.error('Error processing PDF:', error);
        reject(new Error("Could not parse PDF file. It might be corrupted or protected."));
      }
    };

    fileReader.onerror = () => {
        reject(new Error("Error reading file."));
    }

    fileReader.readAsArrayBuffer(file);
  });
}
