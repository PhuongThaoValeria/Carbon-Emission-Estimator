import React, { useState } from 'react';
import { CarbonResult, ThresholdComparison } from '../types';
import { ArrowPathIcon } from './icons/ArrowPathIcon';
import { CopyIcon } from './icons/CopyIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { CheckIcon } from './icons/CheckIcon';
import { ShieldCheckIcon } from './icons/ShieldCheckIcon';
import { ExclamationTriangleIcon } from './icons/ExclamationTriangleIcon';
import { LightBulbIcon } from './icons/LightBulbIcon';
import { DollarSignIcon } from './icons/DollarSignIcon';

interface ResultViewProps {
  result: CarbonResult;
  fileName: string;
  onReset: () => void;
}

// Helper to format keys for display
const formatParamKey = (key: string): string => {
    const keyMap: { [key: string]: string } = {
        hs_code: 'HS Code',
        weight_unit: 'Weight Unit'
    };
    return keyMap[key] || key.charAt(0).toUpperCase() + key.slice(1);
}

const BreakdownSection: React.FC<{ title: string; component: CarbonResult['productEmissions'] | CarbonResult['transportEmissions'] }> = ({ title, component }) => (
    <div className="bg-slate-900/50 p-4 rounded-lg">
        <div className="flex justify-between items-baseline">
            <h3 className="font-semibold text-indigo-300">{title}</h3>
            <p className="font-bold text-lg text-slate-100">{component.value.toFixed(2)} <span className="text-sm font-normal text-slate-400">kg CO₂e</span></p>
        </div>
        <div className="mt-3 border-t border-slate-700 pt-3 space-y-2 text-sm">
            <p className="text-slate-400">
                <span className="font-medium">Formula:</span>
                <code className="ml-2 bg-slate-700 text-indigo-200 px-2 py-1 rounded text-xs">
                    {component.breakdown.formula}
                </code>
            </p>
            {component.breakdown.source && (
                 <p className="text-slate-400">
                    <span className="font-medium">Source:</span>
                    <span className="ml-2 text-slate-300">{component.breakdown.source}</span>
                </p>
            )}
            <ul className="space-y-1.5 pt-2">
            {component.breakdown.steps.map((step, index) => (
                <li key={index} className="text-slate-300 flex items-start">
                    <span className="text-indigo-400 mr-2 mt-0.5">›</span>
                    <span className="flex-1">{step}</span>
                </li>
            ))}
            </ul>
        </div>
    </div>
);

const ThresholdComparisonSection: React.FC<{ comparison: ThresholdComparison, totalFootprint: number }> = ({ comparison, totalFootprint }) => {
    const isAbove = comparison.comparisonResult === 'Above';
    const differenceColor = isAbove ? 'text-amber-400' : 'text-green-400';
    const differencePrefix = comparison.differencePercentage > 0 ? '+' : '';

    return (
        <div className={`p-5 rounded-lg mb-6 ${isAbove ? 'bg-amber-900/50' : 'bg-green-900/50'}`}>
            <h3 className={`font-semibold mb-4 text-lg flex items-center justify-center gap-2 ${isAbove ? 'text-amber-300' : 'text-green-300'}`}>
                {isAbove ? <ExclamationTriangleIcon className="w-6 h-6" /> : <ShieldCheckIcon className="w-6 h-6" />}
                Destination Threshold Analysis ({comparison.destinationCountry})
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-center mb-4">
                <div>
                    <p className="text-sm text-slate-400">Shipment Footprint</p>
                    <p className="text-xl font-bold text-slate-100">{totalFootprint.toFixed(2)} kg CO₂e</p>
                </div>
                <div>
                    <p className="text-sm text-slate-400">Destination Threshold</p>
                    <p className="text-xl font-bold text-slate-100">{comparison.threshold.toFixed(2)} kg CO₂e</p>
                    <p className="text-xs text-slate-500">Source: {comparison.thresholdSource}</p>
                </div>
            </div>

            <div className="text-center border-t border-slate-700/50 pt-4">
                <p className="text-sm text-slate-400">Comparison Result</p>
                <p className={`text-2xl font-bold ${differenceColor} my-1`}>
                    {differencePrefix}{comparison.differencePercentage.toFixed(1)}%
                    <span className="font-semibold ml-2">{comparison.comparisonResult} Threshold</span>
                </p>
                <p className={`mt-3 text-base ${isAbove ? 'text-amber-200' : 'text-green-200'}`}>
                    {comparison.interpretation}
                </p>
                <a 
                    href={comparison.verificationSource} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="mt-3 inline-flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300 underline"
                >
                    Verify Source <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                </a>
            </div>
        </div>
    );
};


const ResultView: React.FC<ResultViewProps> = ({ result, fileName, onReset }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const textToCopy = JSON.stringify({
        fileName,
        ...result
    }, null, 2);
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formattedParams = Object.entries(result.activity.parameters)
    .filter(([_, value]) => value !== undefined && value !== null)
    .map(([key, value]) => ({
        key: formatParamKey(key),
        value: String(value)
    }));
  
  const isOverThreshold = result.thresholdComparison?.comparisonResult === 'Above';

  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-800 rounded-xl shadow-lg p-6 sm:p-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 border-b border-slate-700 pb-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Carbon Emission Estimate</h2>
          <p className="text-slate-400 flex items-center gap-2 mt-1">
            <DocumentTextIcon className="w-5 h-5" />
            <span>{fileName}</span>
          </p>
        </div>
        <div className="flex items-center gap-2 mt-4 sm:mt-0">
          <button
            onClick={handleCopy}
            className="px-4 py-2 bg-slate-700 text-slate-300 font-semibold rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2 text-sm"
          >
            {copied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <CopyIcon className="w-5 h-5" />}
            {copied ? 'Copied!' : 'Copy JSON'}
          </button>
          <button
            onClick={onReset}
            className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2 text-sm"
          >
            <ArrowPathIcon className="w-5 h-5" />
            New PDF
          </button>
        </div>
      </div>

      <div className="text-center my-6 sm:my-8">
        <p className="text-slate-400 text-lg">Total Shipment Footprint</p>
        <p className="text-5xl sm:text-6xl font-bold text-green-400 my-1">
            {result.totalFootprint.toFixed(3)}
        </p>
        <p className="text-slate-300 text-xl">{result.co2e_unit}</p>
        <p className="text-slate-500 text-sm mt-2">Confidence Range: {result.confidenceRange[0].toFixed(2)} – {result.confidenceRange[1].toFixed(2)} kg CO₂e</p>
      </div>
      
      {result.thresholdComparison && (
        <ThresholdComparisonSection comparison={result.thresholdComparison} totalFootprint={result.totalFootprint} />
      )}

      <div className="space-y-4">
        {isOverThreshold && result.suggestions && result.suggestions.length > 0 && (
            <div className="bg-slate-900/50 p-4 rounded-lg">
                <h3 className="font-semibold text-indigo-300 mb-3 border-b border-slate-700 pb-2 flex items-center gap-2">
                    <LightBulbIcon className="w-5 h-5" />
                    AI-Powered Reduction Suggestions
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                    {result.suggestions.map((suggestion, index) => (
                        <div key={index} className={`bg-slate-800 p-4 rounded-lg border ${suggestion.isMostEconomical ? 'border-green-500/50' : 'border-slate-700'} relative flex flex-col`}>
                            {suggestion.isMostEconomical && (
                                <div className="absolute -top-3 right-3 bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 shadow-lg">
                                    <DollarSignIcon className="w-4 h-4" />
                                    Most Economical
                                </div>
                            )}
                            <h4 className="font-bold text-slate-100 mb-2 pr-4">{suggestion.title}</h4>
                            <p className="text-slate-400 text-sm flex-grow">{suggestion.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        )}
        
        <BreakdownSection title="Product Embedded Emissions" component={result.productEmissions} />
        <BreakdownSection title="Transport Emissions" component={result.transportEmissions} />

        <div className="bg-slate-900/50 p-4 rounded-lg">
            <h3 className="font-semibold text-indigo-300 mb-3 border-b border-slate-700 pb-2">Extracted Parameters</h3>
            <dl className="space-y-2">
                <div className="flex justify-between py-1 text-sm">
                    <dt className="text-slate-400 font-medium">Activity Type</dt>
                    <dd className="font-mono text-slate-200 bg-slate-700 px-2 py-0.5 rounded">
                        {result.activity.activityType}
                    </dd>
                </div>
                {formattedParams.map(({key, value}) => (
                    <div key={key} className="flex justify-between py-1 text-sm">
                        <dt className="text-slate-400 font-medium">{key}</dt>
                        <dd className="font-mono text-slate-200 text-right">{value}</dd>
                    </div>
                ))}
            </dl>
        </div>
      </div>
    </div>
  );
};

export default ResultView;
