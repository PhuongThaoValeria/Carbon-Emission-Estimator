
import React, { useCallback, useState, useRef } from 'react';
import { PdfIcon } from './icons/PdfIcon';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);
  
  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type === 'application/pdf') {
      onFileSelect(file);
    } else {
        alert("Please drop a PDF file.");
    }
  }, [onFileSelect]);
  
  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div
      className={`w-full max-w-lg mx-auto p-8 border-2 ${isDragging ? 'border-indigo-500 bg-slate-700/50' : 'border-slate-600 border-dashed'} rounded-xl text-center cursor-pointer transition-all duration-300`}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onClick={handleClick}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept=".pdf"
      />
      <div className="flex flex-col items-center justify-center">
        <PdfIcon className="w-16 h-16 text-slate-500 mb-4" />
        <p className="text-xl font-semibold text-slate-300">
          Drag & drop your PDF here
        </p>
        <p className="text-slate-400">or click to select a file</p>
      </div>
    </div>
  );
};

export default FileUpload;
