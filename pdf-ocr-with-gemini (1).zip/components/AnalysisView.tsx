
import React, { useState, useEffect } from 'react';
import { CarbonActivity } from '../types';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { ArrowPathIcon } from './icons/ArrowPathIcon';
import { PencilIcon } from './icons/PencilIcon';

interface AnalysisViewProps {
  activity: CarbonActivity;
  fileName: string;
  onCalculate: () => void;
  onReset: () => void;
  onUpdateActivity: (activity: CarbonActivity) => void;
}

// Helper to format keys for display
const formatParamKey = (key: string): string => {
    const keyMap: { [key: string]: string } = {
        hs_code: 'HS Code',
        weight_unit: 'Weight Unit'
    };
    return keyMap[key] || key.charAt(0).toUpperCase() + key.slice(1);
}

const inputStyles = "w-full bg-slate-700 border border-slate-600 rounded-md py-2 px-3 text-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition";

const AnalysisView: React.FC<AnalysisViewProps> = ({ activity, fileName, onCalculate, onReset, onUpdateActivity }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editableActivity, setEditableActivity] = useState<CarbonActivity>(activity);

  useEffect(() => {
    // If the parent activity changes (e.g., new file), reset the editable state
    setEditableActivity(activity);
  }, [activity]);

  const handleSave = () => {
    // Ensure weight is stored as a number
    const activityToSave: CarbonActivity = {
      ...editableActivity,
      parameters: {
        ...editableActivity.parameters,
        weight: editableActivity.parameters.weight
          ? parseFloat(String(editableActivity.parameters.weight))
          : undefined,
      },
    };
    onUpdateActivity(activityToSave);
    setIsEditing(false);
  };

  const handleParamChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setEditableActivity((prev) => ({
      ...prev,
      parameters: {
        ...prev.parameters,
        [name]: value,
      },
    }));
  };

  const handleCancelEdit = () => {
    // Revert changes back to original prop
    setEditableActivity(activity);
    setIsEditing(false);
  };

  const formattedParams = Object.entries(activity.parameters)
    .filter(([_, value]) => value !== undefined && value !== null && value !== '')
    .map(([key, value]) => ({
        key: formatParamKey(key),
        value: String(value)
    }));

  const { origin, destination, weight, hs_code } = activity.parameters;
  const isCalculable = 
    activity.activityType === 'shipping' && 
    origin && 
    destination && 
    typeof weight === 'number' &&
    hs_code;

  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-800 rounded-xl shadow-lg p-6 sm:p-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 border-b border-slate-700 pb-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Analysis Complete</h2>
          <p className="text-slate-400 flex items-center gap-2 mt-1">
            <DocumentTextIcon className="w-5 h-5" />
            <span>{fileName}</span>
          </p>
        </div>
         <button
            onClick={onReset}
            className="px-4 py-2 bg-slate-700 text-slate-300 font-semibold rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2 text-sm mt-4 sm:mt-0"
          >
            <ArrowPathIcon className="w-5 h-5" />
            Cancel
          </button>
      </div>

      <div className="bg-slate-900/50 p-4 rounded-lg">
        <div className="flex justify-between items-center mb-3 border-b border-slate-700 pb-2">
            <h3 className="font-semibold text-indigo-300">
                {isEditing ? 'Edit Information' : 'Extracted Information'}
            </h3>
            {!isCalculable && !isEditing && (
                <button
                    onClick={() => setIsEditing(true)}
                    className="px-3 py-1 bg-slate-700 text-slate-300 font-semibold rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2 text-sm"
                >
                    <PencilIcon className="w-4 h-4" />
                    Edit
                </button>
            )}
        </div>

        {isEditing ? (
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }}>
                <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="origin" className="block text-sm font-medium text-slate-400 mb-1">Origin</label>
                            <input type="text" name="origin" id="origin" value={editableActivity.parameters.origin || ''} onChange={handleParamChange} className={inputStyles} placeholder="e.g., Shanghai"/>
                        </div>
                        <div>
                            <label htmlFor="destination" className="block text-sm font-medium text-slate-400 mb-1">Destination</label>
                            <input type="text" name="destination" id="destination" value={editableActivity.parameters.destination || ''} onChange={handleParamChange} className={inputStyles} placeholder="e.g., Hamburg, DE"/>
                        </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                         <div>
                            <label htmlFor="weight" className="block text-sm font-medium text-slate-400 mb-1">Weight</label>
                            <input type="number" name="weight" id="weight" value={editableActivity.parameters.weight || ''} onChange={handleParamChange} className={inputStyles} placeholder="e.g., 15000" step="any" />
                        </div>
                        <div>
                            <label htmlFor="weight_unit" className="block text-sm font-medium text-slate-400 mb-1">Weight Unit</label>
                            <select name="weight_unit" id="weight_unit" value={editableActivity.parameters.weight_unit || 'kg'} onChange={handleParamChange} className={inputStyles}>
                                <option value="kg">kg</option>
                                <option value="lb">lb</option>
                            </select>
                        </div>
                    </div>
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="product" className="block text-sm font-medium text-slate-400 mb-1">Product Description</label>
                            <input type="text" name="product" id="product" value={editableActivity.parameters.product || ''} onChange={handleParamChange} className={inputStyles} placeholder="e.g., Electronic components"/>
                        </div>
                        <div>
                            <label htmlFor="hs_code" className="block text-sm font-medium text-slate-400 mb-1">HS Code</label>
                            <input type="text" name="hs_code" id="hs_code" value={editableActivity.parameters.hs_code || ''} onChange={handleParamChange} className={inputStyles} placeholder="e.g., 854231"/>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-4 mt-6">
                    <button type="button" onClick={handleCancelEdit} className="w-full px-4 py-2 bg-slate-600 text-white font-semibold rounded-lg hover:bg-slate-700 transition-colors">Cancel</button>
                    <button type="submit" className="w-full px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors">Save Changes</button>
                </div>
            </form>
        ) : (
             <>
                {activity.activityType === 'unknown' || formattedParams.length === 0 ? (
                    <p className="text-slate-400 text-sm">Could not extract specific shipping information from the document. Please try a different file or edit the fields manually.</p>
                ) : (
                    <dl className="space-y-2">
                        <div className="flex justify-between py-1 text-sm">
                            <dt className="text-slate-400 font-medium">Activity Type</dt>
                            <dd className="font-mono text-slate-200 bg-slate-700 px-2 py-0.5 rounded">
                                {activity.activityType}
                            </dd>
                        </div>
                        {formattedParams.map(({key, value}) => (
                            <div key={key} className="flex justify-between py-1 text-sm">
                                <dt className="text-slate-400 font-medium">{key}</dt>
                                <dd className="font-mono text-slate-200 text-right">{value}</dd>
                            </div>
                        ))}
                    </dl>
                )}
            </>
        )}
      </div>

      <div className="mt-8 text-center">
        <button
            onClick={onCalculate}
            disabled={!isCalculable || isEditing}
            className="px-8 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors flex items-center gap-3 text-lg mx-auto disabled:bg-slate-600 disabled:cursor-not-allowed"
        >
            <SparklesIcon className="w-6 h-6" />
            Calculate Carbon Footprint
        </button>
        {!isCalculable && !isEditing && (
            <p className="text-sm text-yellow-400 mt-4 max-w-md mx-auto">
                Calculation requires Origin, Destination, Weight, and HS Code. Please edit the fields to proceed.
            </p>
        )}
      </div>
    </div>
  );
};

export default AnalysisView;
