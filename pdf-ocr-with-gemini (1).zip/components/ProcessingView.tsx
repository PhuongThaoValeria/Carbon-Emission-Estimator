import React from 'react';

interface ProcessingViewProps {
  currentPage: number;
  totalPages: number;
  message: string;
}

const ProcessingView: React.FC<ProcessingViewProps> = ({ currentPage, totalPages, message }) => {
  const progressPercentage = totalPages > 0 ? (currentPage / totalPages) * 100 : 0;

  return (
    <div className="flex flex-col items-center justify-center w-full">
      <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500 mb-6"></div>
      <h2 className="text-2xl font-semibold text-slate-200 mb-2">Processing Document...</h2>
      <p className="text-indigo-300 mb-4">{message}</p>
      {totalPages > 0 && (
        <div className="w-full max-w-md text-center">
            <p className="text-slate-400 mb-4">
              Page {currentPage} of {totalPages}
            </p>
            <div className="w-full bg-slate-700 rounded-full h-2.5">
                <div 
                    className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300" 
                    style={{ width: `${progressPercentage}%` }}>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default ProcessingView;
