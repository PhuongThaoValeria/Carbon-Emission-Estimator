
import React from 'react';

export const LeafIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    {...props}
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.82m5.84-2.56a12.022 12.022 0 00-11.66 0 12.022 12.022 0 0011.66 0zM9.75 21.75c-3.131 0-5.94-1.8-7.38-4.38m14.76 0c1.44 2.58 4.249 4.38 7.38 4.38"
    />
  </svg>
);
